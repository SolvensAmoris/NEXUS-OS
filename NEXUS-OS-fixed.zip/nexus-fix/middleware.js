// NOTA: este middleware protege rutas bajo /premium/* a nivel de servidor
// (Vercel Edge Middleware). La SPA actual (index.html) no usa esa ruta —
// el gating de la sección premium ocurre en el cliente via core.verificarAcceso().
// Déjalo aquí si más adelante agregas páginas server-rendered bajo /premium/,
// o bórralo si todo tu producto seguirá siendo una SPA estática.
export const config = { matcher: '/premium/:path*' };

export default async function middleware(request) {
  const tokenMatch = request.headers.get('cookie')?.match(/nexus-auth-token=([^;]+)/);
  if (!tokenMatch) return new Response('Acceso Denegado', { status: 401 });

  const response = await fetch(`${process.env.SUPABASE_URL}/rest/v1/suscripciones?select=estado_pago`, {
    headers: { 'Authorization': `Bearer ${tokenMatch[1]}`, 'apikey': process.env.SUPABASE_ANON_KEY }
  });
  
  const data = await response.json();
  if (data?.[0]?.estado_pago !== 'paid') return new Response('Acceso Prohibido', { status: 403 });
  return;
}
