# NEXUS OS — Guía de Despliegue

## 1. Configurar Supabase

1. Crea un proyecto en [supabase.com](https://supabase.com) si no tienes uno.
2. Ve a **SQL Editor** y ejecuta el contenido de `supabase/migrations/001_init_schema.sql`.
   Esto crea las tablas `suscripciones` y `ventas`, con Row Level Security activado.
3. Ve a **Project Settings → API** y copia:
   - `Project URL`
   - `anon` / `public` key

## 2. Configurar el frontend

Edita `app.js`, líneas 7-8, y reemplaza:

```js
const SUPABASE_URL = "https://TU_PROYECTO.supabase.co";
const SUPABASE_ANON_KEY = "TU_ANON_KEY";
```

con tus valores reales.

## 3. Configurar Stripe

1. En tu Dashboard de Stripe, copia el **Price ID** del producto/plan que ya creaste
   (Dashboard → Products → tu producto → Pricing → el ID empieza con `price_`).
2. Edita `supabase/functions/stripe-checkout/index.ts`, línea 11, y reemplaza:

```ts
const STRIPE_PRICE_ID = Deno.env.get('STRIPE_PRICE_ID') ?? 'price_REEMPLAZAR_CON_TU_PRICE_ID'
```

   con tu Price ID (o, mejor, configúralo como variable de entorno `STRIPE_PRICE_ID`
   al desplegar la función — así no queda hardcodeado).

3. Crea un **Webhook endpoint** en Stripe (Developers → Webhooks → Add endpoint)
   apuntando a la URL que tendrá tu función `stripe-webhook` una vez desplegada
   (ver paso 4). Selecciona estos eventos:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`

   Copia el **Signing secret** (`whsec_...`) que te da Stripe al crear el endpoint.

## 4. Desplegar las Edge Functions

Con el [Supabase CLI](https://supabase.com/docs/guides/cli) instalado:

```bash
supabase login
supabase link --project-ref TU_PROJECT_REF

# Variables de entorno que necesitan las funciones (NUNCA en el frontend):
supabase secrets set STRIPE_SECRET_KEY=sk_live_o_test_...
supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
supabase secrets set STRIPE_PRICE_ID=price_...
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=tu_service_role_key

supabase functions deploy stripe-checkout
supabase functions deploy stripe-portal
supabase functions deploy stripe-webhook --no-verify-jwt
```

> `--no-verify-jwt` es necesario en `stripe-webhook` porque Stripe llama a este
> endpoint directamente (no manda un JWT de usuario de Supabase).

Después de desplegar, copia la URL de `stripe-webhook` y pégala en el endpoint
de Stripe que creaste en el paso 3.

## 5. Desplegar el frontend

Sube `index.html`, `app.js`, `css/`, `agents/`, `storage/`, `manifest.json` y
`middleware.js` a Vercel, Netlify, GitHub Pages, o cualquier hosting estático.

Si usas Vercel y quieres aprovechar `middleware.js` para proteger rutas
server-side bajo `/premium/*`, configura las variables de entorno
`SUPABASE_URL` y `SUPABASE_ANON_KEY` en el proyecto de Vercel.

## 6. Pendiente: íconos del manifest

`manifest.json` referencia `icons/icon-192.png` e `icons/icon-512.png`, que
no existen todavía. No bloquean el funcionamiento de la app, pero el
navegador mostrará una advertencia en la consola y la app no tendrá ícono
al "Agregar a pantalla de inicio". Agrega esos dos PNGs en una carpeta
`icons/` cuando tengas el branding final.

## Flujo completo una vez desplegado

1. Usuario se registra/inicia sesión → trigger SQL le crea automáticamente
   una fila en `suscripciones` con `estado_pago = 'pending'`.
2. Ve la sección "Núcleo Clasificado" con botón "Forjar Alianza (Pagar)".
3. Al pagar, Stripe redirige a Checkout → al completar, dispara el webhook
   `checkout.session.completed` → el webhook (con `service_role` key)
   actualiza `estado_pago = 'paid'`.
4. Usuario recarga o vuelve a la app → `verificarAcceso()` detecta `paid` →
   se desbloquea el módulo de Registro Contable.
5. Usuario escribe instrucciones en lenguaje natural ("gasto de 500 a
   proveedor", "resumen") → `Agent.procesarInstruccion()` las interpreta →
   `CloudManager.guardarVenta()` las guarda en la tabla `ventas` (con RLS,
   solo visibles para ese usuario).
6. Puede exportar su historial a CSV en cualquier momento.
