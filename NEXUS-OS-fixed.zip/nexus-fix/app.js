// ============================================================
// NEXUS OS — Núcleo de aplicación
// Reemplaza estos valores con los de tu proyecto Supabase
// (Project Settings > API). El ANON KEY es público, es seguro
// dejarlo en el frontend.
// ============================================================
const SUPABASE_URL = "https://TU_PROYECTO.supabase.co";
const SUPABASE_ANON_KEY = "TU_ANON_KEY";

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const core = {
    currentUserId: null,

    async init() {
        const { data: { session } } = await supabase.auth.getSession();
        this.updateUI(session);

        supabase.auth.onAuthStateChange((_event, session) => {
            if (session) {
                document.cookie = `nexus-auth-token=${session.access_token}; path=/; max-age=${session.expires_in}; secure; samesite=strict`;
            } else {
                document.cookie = `nexus-auth-token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
            }
            this.updateUI(session);
        });

        // Si Stripe redirige de vuelta tras un pago, mostrar feedback inmediato
        const params = new URLSearchParams(window.location.search);
        if (params.get('pago') === 'exito') {
            this.mostrarMensaje('Pago recibido. Activando tu acceso… (puede tardar unos segundos)', 'ok');
        } else if (params.get('pago') === 'cancelado') {
            this.mostrarMensaje('Pago cancelado.', 'warn');
        }
    },

    mostrarMensaje(texto, tipo = 'info') {
        const el = document.getElementById('mensaje');
        if (!el) return;
        el.textContent = texto;
        el.className = `mensaje mensaje-${tipo}`;
        el.classList.remove('hidden');
        setTimeout(() => el.classList.add('hidden'), 5000);
    },

    async register() {
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;

        if (!email || !password) {
            this.mostrarMensaje('Ingresa correo y contraseña.', 'warn');
            return;
        }
        if (password.length < 6) {
            this.mostrarMensaje('La contraseña debe tener al menos 6 caracteres.', 'warn');
            return;
        }

        const { data, error } = await supabase.auth.signUp({ email, password });

        if (error) {
            this.mostrarMensaje(`Error al registrar: ${error.message}`, 'error');
            return;
        }

        if (data.session) {
            this.mostrarMensaje('Registro exitoso. Bienvenido.', 'ok');
        } else {
            // Si la confirmación de correo está activada en Supabase
            this.mostrarMensaje('Revisa tu correo para confirmar tu cuenta.', 'ok');
        }
    },

    async login() {
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;

        if (!email || !password) {
            this.mostrarMensaje('Ingresa correo y contraseña.', 'warn');
            return;
        }

        const { error } = await supabase.auth.signInWithPassword({ email, password });

        if (error) {
            this.mostrarMensaje(`Error al iniciar sesión: ${error.message}`, 'error');
            return;
        }

        this.mostrarMensaje('Sesión iniciada.', 'ok');
    },

    async logout() {
        await supabase.auth.signOut();
        this.mostrarMensaje('Sesión cerrada.', 'info');
    },

    updateUI(session) {
        const authSec = document.getElementById('auth-section');
        const dashSec = document.getElementById('dashboard-section');
        const premiumSec = document.getElementById('premium-section');

        if (session) {
            this.currentUserId = session.user.id;
            authSec.classList.add('hidden');
            dashSec.classList.remove('hidden');
            document.getElementById('user-display').textContent = session.user.email;
            this.verificarAcceso(session.user.id);
        } else {
            this.currentUserId = null;
            authSec.classList.remove('hidden');
            dashSec.classList.add('hidden');
            premiumSec.classList.add('hidden');
        }
    },

    async verificarAcceso(userId) {
        const { data, error } = await supabase
            .from('suscripciones')
            .select('estado_pago')
            .eq('user_id', userId)
            .single();

        if (error) {
            console.error('Error verificando acceso:', error.message);
        }

        const estado = data?.estado_pago;
        const statusDisplay = document.getElementById('status-display');
        const premiumContent = document.getElementById('premium-content');
        const btnPay = document.getElementById('btn-pay');

        if (estado === 'paid') {
            statusDisplay.textContent = 'Activo';
            premiumContent.classList.remove('hidden');
            btnPay.classList.add('hidden');
            this.initVentasModule();
        } else if (estado === 'past_due') {
            statusDisplay.textContent = 'Pago pendiente de renovación';
            premiumContent.classList.add('hidden');
            btnPay.classList.remove('hidden');
        } else {
            statusDisplay.textContent = 'Pendiente';
            premiumContent.classList.add('hidden');
            btnPay.classList.remove('hidden');
        }

        document.getElementById('premium-section').classList.remove('hidden');
    },

    async iniciarPago() {
        const btn = document.getElementById('btn-pay');
        btn.disabled = true;
        btn.textContent = 'Generando enlace de pago…';

        const { data, error } = await supabase.functions.invoke('stripe-checkout');

        if (error || !data?.url) {
            this.mostrarMensaje('No se pudo iniciar el pago. Intenta de nuevo.', 'error');
            btn.disabled = false;
            btn.textContent = 'Forjar Alianza (Pagar)';
            return;
        }

        window.location.href = data.url;
    },

    async gestionarPortal() {
        const { data, error } = await supabase.functions.invoke('stripe-portal');

        if (error || !data?.url) {
            this.mostrarMensaje('No se pudo abrir el portal de gestión.', 'error');
            return;
        }

        window.location.href = data.url;
    },

    // ----------------------------------------------------------
    // Módulo de Ventas — solo disponible para usuarios con acceso pagado.
    // Usa el Agente (agents/agent.js) para interpretar instrucciones en
    // lenguaje natural y CloudManager (storage/cloud.js) para persistirlas.
    // ----------------------------------------------------------
    ventasInicializado: false,

    async initVentasModule() {
        if (this.ventasInicializado) {
            this.refrescarVentas();
            return;
        }
        this.ventasInicializado = true;
        this.refrescarVentas();
    },

    async procesarInstruccionVentas() {
        const input = document.getElementById('ventas-input');
        const texto = input.value.trim();
        if (!texto) return;

        const resultado = await Agent.procesarInstruccion(texto);

        if (resultado.comando === 'ERROR') {
            this.mostrarMensaje(resultado.plantilla, 'warn');
            return;
        }

        if (resultado.comando === 'REPORTE_EJECUTIVO') {
            await this.mostrarReporteEjecutivo();
            input.value = '';
            return;
        }

        if (resultado.comando === 'REGISTRO_CONTABLE') {
            const guardado = await CloudManager.guardarVenta({
                ...resultado.datos,
                user_id: this.currentUserId,
            });

            if (guardado === null) {
                this.mostrarMensaje('No se pudo guardar el movimiento.', 'error');
                return;
            }

            this.mostrarMensaje(resultado.plantilla, 'ok');
            input.value = '';
            this.refrescarVentas();
        }
    },

    async refrescarVentas() {
        const lista = await CloudManager.listarVentas(this.currentUserId);
        const contenedor = document.getElementById('ventas-lista');
        if (!contenedor) return;

        if (!lista || lista.length === 0) {
            contenedor.innerHTML = '<p class="muted">Sin movimientos registrados aún.</p>';
            return;
        }

        const caja = lista.reduce((acc, v) => acc + (v.tipo === 'ingreso' ? Number(v.monto) : -Number(v.monto)), 0);
        document.getElementById('ventas-caja').textContent = `$${caja.toFixed(2)} MXN`;

        contenedor.innerHTML = lista.slice(0, 10).map(v => `
            <div class="movimiento movimiento-${v.tipo}">
                <span>${v.tipo === 'ingreso' ? '+' : '−'}$${Number(v.monto).toFixed(2)}</span>
                <span class="muted">${v.cliente || 'anonimo'}</span>
                <span class="muted">${new Date(v.fecha).toLocaleDateString('es-MX')}</span>
            </div>
        `).join('');
    },

    async mostrarReporteEjecutivo() {
        const lista = await CloudManager.listarVentas(this.currentUserId);
        const ingresos = lista.filter(v => v.tipo === 'ingreso').reduce((a, v) => a + Number(v.monto), 0);
        const egresos = lista.filter(v => v.tipo === 'egreso').reduce((a, v) => a + Number(v.monto), 0);
        this.mostrarMensaje(
            `📊 Reporte: ${lista.length} movimientos · Ingresos $${ingresos.toFixed(2)} · Egresos $${egresos.toFixed(2)} · Neto $${(ingresos - egresos).toFixed(2)}`,
            'info'
        );
    },

    async exportarReporte() {
        const lista = await CloudManager.listarVentas(this.currentUserId);
        StorageManager.exportarCSV(lista);
    }
};

window.addEventListener('DOMContentLoaded', () => core.init());
