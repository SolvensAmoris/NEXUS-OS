const StorageManager = {
    init: function() {
        if (!localStorage.getItem('nexus_data')) {
            const initialData = { caja: 0, transacciones: [] };
            localStorage.setItem('nexus_data', JSON.stringify(initialData));
            return initialData;
        }
        return JSON.parse(localStorage.getItem('nexus_data'));
    },
    getData: function() { return JSON.parse(localStorage.getItem('nexus_data')); },
    registrarMovimiento: function(tipo, monto) {
        const data = this.getData();
        if (tipo === 'ingreso') data.caja += monto;
        else data.caja -= monto;
        data.transacciones.push({ id: Date.now(), tipo, monto, fecha: new Date().toLocaleDateString() });
        localStorage.setItem('nexus_data', JSON.stringify(data));
        return data.caja;
    },
    // Acepta una lista opcional de movimientos (p. ej. desde Supabase via
    // CloudManager.listarVentas). Si no se provee, usa el caché local.
    exportarCSV: function(movimientos) {
        const filas = movimientos || this.getData().transacciones;
        let csvContent = "data:text/csv;charset=utf-8,ID,Tipo,Monto,Cliente,Fecha\n";
        filas.forEach(row => {
            const id = row.id || '';
            const cliente = row.cliente || '';
            const fecha = row.fecha || '';
            csvContent += `${id},${row.tipo},${row.monto},${cliente},${fecha}\n`;
        });
        const link = document.createElement("a");
        link.setAttribute("href", encodeURI(csvContent));
        link.setAttribute("download", "NEXUS_OS_Reporte.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};
