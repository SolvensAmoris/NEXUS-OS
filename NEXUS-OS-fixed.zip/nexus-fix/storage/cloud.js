// ============================================================
// CloudManager — persistencia de movimientos (tabla `ventas`)
// Reutiliza el cliente `supabase` ya creado en app.js.
// IMPORTANTE: este script debe cargarse DESPUÉS de app.js.
// ============================================================
const CloudManager = {
    guardarVenta: async function(datos) {
        try {
            const { data, error } = await supabase
                .from('ventas')
                .insert([{
                    user_id: datos.user_id,
                    tipo: (datos.tipo || 'ingreso').toLowerCase(),
                    monto: datos.monto || 0,
                    fecha: datos.fecha || new Date().toISOString(),
                    categoria: (datos.categoria || 'general').toLowerCase(),
                    cliente: (datos.cliente || 'anonimo').toLowerCase(),
                    metodo_pago: (datos.metodo_pago || 'n/a').toLowerCase(),
                    notas: (datos.notas || '').toLowerCase()
                }])
                .select();

            if (error) throw error;
            return data;
        } catch (err) {
            console.error('Error al registrar venta:', err.message);
            return null;
        }
    },

    listarVentas: async function(userId) {
        if (!userId) return [];
        try {
            const { data, error } = await supabase
                .from('ventas')
                .select('*')
                .eq('user_id', userId)
                .order('fecha', { ascending: false })
                .limit(50);

            if (error) throw error;
            return data;
        } catch (err) {
            console.error('Error al listar ventas:', err.message);
            return [];
        }
    }
};
