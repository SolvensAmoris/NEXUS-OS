-- ============================================================
-- NEXUS OS — Esquema inicial
-- Tablas: suscripciones (auth/pagos) y ventas (registro contable)
-- ============================================================

-- ---------- TABLA: suscripciones ----------
create table if not exists public.suscripciones (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  estado_pago text not null default 'pending' check (estado_pago in ('pending', 'paid', 'canceled', 'past_due')),
  stripe_customer_id text,
  stripe_subscription_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id)
);

create index if not exists idx_suscripciones_user_id on public.suscripciones(user_id);
create index if not exists idx_suscripciones_stripe_customer on public.suscripciones(stripe_customer_id);

alter table public.suscripciones enable row level security;

-- El usuario solo puede leer su propio registro de suscripción
drop policy if exists "suscripciones_select_own" on public.suscripciones;
create policy "suscripciones_select_own"
  on public.suscripciones for select
  using (auth.uid() = user_id);

-- Nadie puede insertar/actualizar/eliminar desde el cliente.
-- Solo las Edge Functions (con service_role key) pueden escribir aquí,
-- vía webhook de Stripe. Esto evita que un usuario se "auto-otorgue" acceso pagado.

-- Trigger para crear automáticamente una fila "pending" al registrarse
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.suscripciones (user_id, estado_pago)
  values (new.id, 'pending')
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Mantener updated_at al día
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_suscripciones_updated_at on public.suscripciones;
create trigger trg_suscripciones_updated_at
  before update on public.suscripciones
  for each row execute function public.set_updated_at();


-- ---------- TABLA: ventas ----------
-- Registro contable de ingresos/egresos (módulo del agente conversacional)
create table if not exists public.ventas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tipo text not null check (tipo in ('ingreso', 'egreso')),
  monto numeric(12, 2) not null check (monto >= 0),
  categoria text default 'general',
  cliente text default 'anonimo',
  metodo_pago text default 'n/a',
  notas text default '',
  fecha timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists idx_ventas_user_id on public.ventas(user_id);
create index if not exists idx_ventas_fecha on public.ventas(fecha desc);

alter table public.ventas enable row level security;

-- El usuario solo ve/crea/edita/borra sus propios movimientos
drop policy if exists "ventas_select_own" on public.ventas;
create policy "ventas_select_own"
  on public.ventas for select
  using (auth.uid() = user_id);

drop policy if exists "ventas_insert_own" on public.ventas;
create policy "ventas_insert_own"
  on public.ventas for insert
  with check (auth.uid() = user_id);

drop policy if exists "ventas_update_own" on public.ventas;
create policy "ventas_update_own"
  on public.ventas for update
  using (auth.uid() = user_id);

drop policy if exists "ventas_delete_own" on public.ventas;
create policy "ventas_delete_own"
  on public.ventas for delete
  using (auth.uid() = user_id);
