import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import Stripe from 'https://esm.sh/stripe@12.0.0?target=deno'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0'

// Este endpoint NO usa el JWT del usuario: Stripe lo llama directamente (server-to-server).
// La autenticidad se valida con la firma del webhook, no con un Authorization header.

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') as string, {
  apiVersion: '2022-11-15',
  httpClient: Stripe.createFetchHttpClient(),
})

const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET') as string

const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
)

async function actualizarEstado(customerId: string, estado: 'paid' | 'canceled' | 'past_due', subscriptionId?: string) {
  const update: Record<string, unknown> = { estado_pago: estado }
  if (subscriptionId) update.stripe_subscription_id = subscriptionId

  const { error } = await supabaseAdmin
    .from('suscripciones')
    .update(update)
    .eq('stripe_customer_id', customerId)

  if (error) console.error('Error actualizando suscripción:', error.message)
}

serve(async (req) => {
  const signature = req.headers.get('Stripe-Signature')
  const body = await req.text()

  let event: Stripe.Event
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature!, webhookSecret)
  } catch (err) {
    return new Response(`Firma inválida: ${err.message}`, { status: 400 })
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        if (session.customer && session.mode === 'subscription') {
          await actualizarEstado(
            session.customer as string,
            'paid',
            session.subscription as string
          )
        }
        break
      }

      case 'customer.subscription.updated': {
        const sub = event.data.object as Stripe.Subscription
        const estado = sub.status === 'active' ? 'paid'
          : sub.status === 'past_due' ? 'past_due'
          : 'canceled'
        await actualizarEstado(sub.customer as string, estado, sub.id)
        break
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription
        await actualizarEstado(sub.customer as string, 'canceled', sub.id)
        break
      }

      default:
        // Evento no manejado; se ignora intencionalmente.
        break
    }

    return new Response(JSON.stringify({ received: true }), { status: 200 })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 })
  }
})
