import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import Stripe from 'https://esm.sh/stripe@12.0.0?target=deno'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') as string, {
  apiVersion: '2022-11-15',
  httpClient: Stripe.createFetchHttpClient(),
})

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const authHeader = req.headers.get('Authorization')!
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    // 1. Verificación de Identidad
    const { data: { user } } = await supabaseClient.auth.getUser()
    if (!user) throw new Error('Entidad no autenticada.')

    // 2. Extracción del Artefacto de Cliente (Stripe ID)
    const { data: suscripcion, error } = await supabaseClient
      .from('suscripciones')
      .select('stripe_customer_id')
      .eq('user_id', user.id)
      .single()

    if (error || !suscripcion?.stripe_customer_id) {
        throw new Error('Identificador de cliente ausente en el grimorio.')
    }

    const origin = req.headers.get('origin') || 'http://localhost:3000'

    // 3. Generación del Portal de Autogestión
    const session = await stripe.billingPortal.sessions.create({
      customer: suscripcion.stripe_customer_id,
      return_url: origin,
    })

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    })
  }
})
