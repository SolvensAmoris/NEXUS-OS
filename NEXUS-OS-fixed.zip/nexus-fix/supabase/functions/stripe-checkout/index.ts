import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import Stripe from 'https://esm.sh/stripe@12.0.0?target=deno'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.23.0'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') as string, {
  apiVersion: '2022-11-15',
  httpClient: Stripe.createFetchHttpClient(),
})

// Price ID de tu producto en Stripe (Dashboard > Productos > [tu plan] > Pricing).
// Se puede sobreescribir con la variable de entorno STRIPE_PRICE_ID si prefieres no hardcodearlo.
const STRIPE_PRICE_ID = Deno.env.get('STRIPE_PRICE_ID') ?? 'price_REEMPLAZAR_CON_TU_PRICE_ID'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const authHeader = req.headers.get('Authorization')!
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    // 1. Verificación de identidad
    const { data: { user } } = await supabaseClient.auth.getUser()
    if (!user) throw new Error('Entidad no autenticada.')

    // 2. Buscar o crear el customer de Stripe para este usuario
    const { data: suscripcion } = await supabaseClient
      .from('suscripciones')
      .select('stripe_customer_id')
      .eq('user_id', user.id)
      .single()

    let customerId = suscripcion?.stripe_customer_id

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: { supabase_user_id: user.id },
      })
      customerId = customer.id

      // Guardar el customer_id usando el cliente admin (service_role),
      // porque el cliente con anon key no tiene permiso de escritura en suscripciones.
      const supabaseAdmin = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      )
      await supabaseAdmin
        .from('suscripciones')
        .update({ stripe_customer_id: customerId })
        .eq('user_id', user.id)
    }

    const origin = req.headers.get('origin') || 'http://localhost:3000'

    // 3. Crear la sesión de Checkout
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
      mode: 'subscription',
      success_url: `${origin}?pago=exito`,
      cancel_url: `${origin}?pago=cancelado`,
      metadata: { supabase_user_id: user.id },
      subscription_data: {
        metadata: { supabase_user_id: user.id },
      },
    })

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    })
  }
})
